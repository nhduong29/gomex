try
{
	document.getElementsByClassName('wishlist-text-default wishlist-text-add id-track-click')[0].click();
}catch(ex)
{

}